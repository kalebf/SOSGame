module com.example.sosgame {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.junit.jupiter.api;
	requires javafx.graphics;
    exports com.example.sosgame;
    opens com.example.sosgame to javafx.graphics;
}