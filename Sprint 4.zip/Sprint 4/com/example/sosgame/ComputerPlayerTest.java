package com.example.sosgame;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ComputerPlayerTest {
    private GameBoard board;
    
    @BeforeEach
    public void setUp() {	// Initialize a new board before each test
        board = new GameBoard(5);
        
    }

    @Test
    // Setup a winning opportunity for S-O-S (horizontal)
    public void tmakeImprovedMove_CompletesWinningSOS() { 
        board.placeSymbol(0, 0, 'S');
        board.placeSymbol(0, 1, 'O');
        // Computer should place 'S' at (0,2)
        Move move = ComputerPlayer.makeImprovedMove(board); 
        assertEquals(0, move.row);
        assertEquals(2, move.col);
        assertEquals('S', move.symbol);
    }

    @Test
    // Setup a Blocking move for S-O-S (vertical)
    public void makeImprovedMove_BlocksOpponentWin() {
        // Setup opponent's potential S-O-S (vertical)
        board.placeSymbol(0, 0, 'S');
        board.placeSymbol(1, 0, 'O');
        // Computer should block at (2,0)
        Move move = ComputerPlayer.makeImprovedMove(board);
        assertEquals(2, move.row);
        assertEquals(0, move.col);
        assertTrue(move.symbol == 'S' || move.symbol == 'O');
    }
   
    @Test
    public void makeImprovedMove_AvoidsCreatingOpponentOpportunities() {
        // Setup where a naive move would create opponent opportunity
        board.placeSymbol(0, 0, 'S');
        board.placeSymbol(2, 0, 'O');
        
        Move move = ComputerPlayer.makeImprovedMove(board);
        board.placeSymbol(move.row, move.col, move.symbol);
        
        // Verify no immediate win opportunity created for opponent
        for (int r = 0; r < board.getSize(); r++) {
            for (int c = 0; c < board.getSize(); c++) {
                if (board.isCellEmpty(r, c)) {
                    assertFalse(ComputerPlayer.wouldCompleteSOS(board, r, c, 'S') ||
                               ComputerPlayer.wouldCompleteSOS(board, r, c, 'O'));
                }
            }
        }
    }

    @Test
    public void testWouldCompleteSOS_Vertical() {
        board.placeSymbol(0, 0, 'S');
        board.placeSymbol(1, 0, 'O');
        assertTrue(ComputerPlayer.wouldCompleteSOS(board, 2, 0, 'S'));
    }

    @Test
    public void testWouldCompleteSOS_Horizontal() {
        board.placeSymbol(0, 0, 'S');
        board.placeSymbol(0, 1, 'O');
        assertTrue(ComputerPlayer.wouldCompleteSOS(board, 0, 2, 'S'));
    }

    @Test
    public void testWouldCompleteSOS_Diagonal() {
        board.placeSymbol(0, 0, 'S');
        board.placeSymbol(1, 1, 'O');
        assertTrue(ComputerPlayer.wouldCompleteSOS(board, 2, 2, 'S'));
    }

    @Test
    public void testWouldCompleteSOS_OInMiddle() {
        board.placeSymbol(0, 0, 'S');
        board.placeSymbol(0, 2, 'S');
        assertTrue(ComputerPlayer.wouldCompleteSOS(board, 0, 1, 'O'));
    }
}