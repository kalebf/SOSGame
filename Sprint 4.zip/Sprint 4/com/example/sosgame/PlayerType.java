package com.example.sosgame;

public enum PlayerType {
    HUMAN,
    COMPUTER_EASY
}