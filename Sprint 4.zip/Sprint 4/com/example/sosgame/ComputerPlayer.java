package com.example.sosgame;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class ComputerPlayer {
    private static final Random random = new Random();
    
    public static Move makeImprovedMove(GameBoard board) {
        // 1. First priority: Complete an existing SOS (unchanged)
        Move winningMove = findWinningMove(board);
        if (winningMove != null) return winningMove;

        // 2. Second priority: Block opponent while avoiding creating new threats
        Move safeBlockingMove = findSafeBlockingMove(board);
        if (safeBlockingMove != null) return safeBlockingMove;

        // 3. Third priority: Create potential setups that don't help opponent
        Move safeSetupMove = findSafeSetupMove(board);
        if (safeSetupMove != null) return safeSetupMove;

        // 4. Final fallback: Random move that doesn't create immediate threats
        return makeSafeRandomMove(board);
    }

    private static Move findWinningMove(GameBoard board) {
		// TODO Auto-generated method stub
		return null;
	}

	private static Move findSafeBlockingMove(GameBoard board) {
        List<Move> allBlockingMoves = new ArrayList<>();
        
        // Find all potential blocking moves first
        for (int row = 0; row < board.getSize(); row++) {
            for (int col = 0; col < board.getSize(); col++) {
                if (board.isCellEmpty(row, col)) {
                    if (wouldCompleteSOS(board, row, col, 'S')) {
                        allBlockingMoves.add(new Move(row, col, 'S'));
                    }
                    if (wouldCompleteSOS(board, row, col, 'O')) {
                        allBlockingMoves.add(new Move(row, col, 'O'));
                    }
                }
            }
        }

        // Evaluate which blocking moves are safest
        for (Move move : allBlockingMoves) {
            // Simulate the blocking move
            board.placeSymbol(move.row, move.col, move.symbol);
            
            // Check if this creates an opportunity for opponent
            boolean createsThreat = false;
            for (int r = 0; r < board.getSize(); r++) {
                for (int c = 0; c < board.getSize(); c++) {
                    if (board.isCellEmpty(r, c)) {
                        if (wouldCompleteSOS(board, r, c, 'S') || 
                            wouldCompleteSOS(board, r, c, 'O')) {
                            createsThreat = true;
                            break;
                        }
                    }
                }
                if (createsThreat) break;
            }
            
            // Undo the simulation
            board.placeSymbol(move.row, move.col, ' ');
            
            if (!createsThreat) {
                return move; // Found a safe blocking move
            }
        }
        
        // If no completely safe blocks, return the first blocking move
        return allBlockingMoves.isEmpty() ? null : allBlockingMoves.get(0);
    }

    private static Move findSafeSetupMove(GameBoard board) {
        List<Move> potentialMoves = new ArrayList<>();
        
        // Find all potential setup moves
        for (int row = 0; row < board.getSize(); row++) {
            for (int col = 0; col < board.getSize(); col++) {
                if (board.isCellEmpty(row, col)) {
                    // Prefer 'S' for setup as it offers more possibilities
                    potentialMoves.add(new Move(row, col, 'S'));
                    potentialMoves.add(new Move(row, col, 'O'));
                }
            }
        }
        
        // Shuffle to add randomness
        Collections.shuffle(potentialMoves);
        
        // Find first move that doesn't create opponent opportunities
        for (Move move : potentialMoves) {
            board.placeSymbol(move.row, move.col, move.symbol);
            
            boolean createsThreat = false;
            for (int r = 0; r < board.getSize(); r++) {
                for (int c = 0; c < board.getSize(); c++) {
                    if (board.isCellEmpty(r, c)) {
                        if (wouldCompleteSOS(board, r, c, 'S') || 
                            wouldCompleteSOS(board, r, c, 'O')) {
                            createsThreat = true;
                            break;
                        }
                    }
                }
                if (createsThreat) break;
            }
            
            board.placeSymbol(move.row, move.col, ' ');
            
            if (!createsThreat) {
                return move;
            }
        }
        
        return null;
    }

    private static Move makeSafeRandomMove(GameBoard board) {
        List<Move> safeMoves = new ArrayList<>();
        
        // Collect all empty cells
        for (int row = 0; row < board.getSize(); row++) {
            for (int col = 0; col < board.getSize(); col++) {
                if (board.isCellEmpty(row, col)) {
                    safeMoves.add(new Move(row, col, 'S'));
                    safeMoves.add(new Move(row, col, 'O'));
                }
            }
        }
        
        // Shuffle to randomize
        Collections.shuffle(safeMoves);
        
        // Find first move that doesn't create opponent opportunities
        for (Move move : safeMoves) {
            board.placeSymbol(move.row, move.col, move.symbol);
            
            boolean createsThreat = false;
            for (int r = 0; r < board.getSize(); r++) {
                for (int c = 0; c < board.getSize(); c++) {
                    if (board.isCellEmpty(r, c)) {
                        if (wouldCompleteSOS(board, r, c, 'S') || 
                            wouldCompleteSOS(board, r, c, 'O')) {
                            createsThreat = true;
                            break;
                        }
                    }
                }
                if (createsThreat) break;
            }
            
            board.placeSymbol(move.row, move.col, ' ');
            
            if (!createsThreat) {
                return move;
            }
        }
        
        // If all moves create threats, just return a random one
        return safeMoves.isEmpty() ? null : safeMoves.get(0);
    }

    
	static boolean wouldCompleteSOS(GameBoard board, int row, int col, char symbol) {
        // Temporarily place the symbol
        board.placeSymbol(row, col, symbol);
        
        // Check all directions for SOS completion
        boolean completesSOS = checkAllDirections(board, row, col, symbol);
        
        // Undo the temporary placement
        board.placeSymbol(row, col, ' ');
        
        return completesSOS;
    }

    private static boolean checkAllDirections(GameBoard board, int row, int col, char symbol) {
        int size = board.getSize();
        char[][] grid = board.getBoard();
        
        if (symbol == 'S') {
            // Check for S-O-S pattern in all directions
            // Horizontal
            if (col >= 2 && grid[row][col-1] == 'O' && grid[row][col-2] == 'S') return true;
            if (col <= size-3 && grid[row][col+1] == 'O' && grid[row][col+2] == 'S') return true;
            // Vertical
            if (row >= 2 && grid[row-1][col] == 'O' && grid[row-2][col] == 'S') return true;
            if (row <= size-3 && grid[row+1][col] == 'O' && grid[row+2][col] == 'S') return true;
            // Diagonals
            if (row >= 2 && col >= 2 && grid[row-1][col-1] == 'O' && grid[row-2][col-2] == 'S') return true;
            if (row <= size-3 && col <= size-3 && grid[row+1][col+1] == 'O' && grid[row+2][col+2] == 'S') return true;
            if (row >= 2 && col <= size-3 && grid[row-1][col+1] == 'O' && grid[row-2][col+2] == 'S') return true;
            if (row <= size-3 && col >= 2 && grid[row+1][col-1] == 'O' && grid[row+2][col-2] == 'S') return true;
        } else if (symbol == 'O') {
            // Check for S-O-S pattern where this O is in the middle
            // Horizontal
            if (col > 0 && col < size-1 && grid[row][col-1] == 'S' && grid[row][col+1] == 'S') return true;
            // Vertical
            if (row > 0 && row < size-1 && grid[row-1][col] == 'S' && grid[row+1][col] == 'S') return true;
            // Diagonals
            if (row > 0 && col > 0 && row < size-1 && col < size-1 && 
                grid[row-1][col-1] == 'S' && grid[row+1][col+1] == 'S') return true;
            if (row > 0 && col < size-1 && row < size-1 && col > 0 && 
                grid[row-1][col+1] == 'S' && grid[row+1][col-1] == 'S') return true;
        }
        return false;
        }
}