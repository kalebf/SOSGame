module com.example.sosgame {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.junit.jupiter.api; // Add this line for JUnit 5
    opens com.example.sosgame to javafx.graphics;
}