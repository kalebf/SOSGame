package com.example.sosgame;

public class SOSGameLauncher {
    public static void main(String[] args) {
        SOSGameGUI.launch(SOSGameGUI.class, args);
    }
}