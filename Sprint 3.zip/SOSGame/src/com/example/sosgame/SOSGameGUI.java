package com.example.sosgame;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import javafx.scene.text.Font;
import javafx.geometry.Pos;
import java.util.List;

public class SOSGameGUI extends Application {
    private SOSGameBase game;
    private GridPane boardGrid;
    private Label statusLabel;
    private Label blueScoreLabel;
    private Label redScoreLabel;
    private Pane boardContainer;
    
    @Override
    public void start(Stage primaryStage) {
        // Setup game options panel
        ComboBox<Integer> sizeCombo = new ComboBox<>();
        sizeCombo.getItems().addAll(3, 4, 5, 6, 7, 8, 9, 10);
        sizeCombo.setValue(5);

        ToggleGroup modeGroup = new ToggleGroup();
        RadioButton simpleMode = new RadioButton("Simple Game");
        RadioButton generalMode = new RadioButton("General Game");
        simpleMode.setToggleGroup(modeGroup);
        generalMode.setToggleGroup(modeGroup);
        simpleMode.setSelected(true);

        // THIS IS THE BUTTON ACTION HANDLER:
        Button startButton = new Button("Start Game");
        startButton.setOnAction(e -> {
            // Get selected mode
            SOSGameBase.GameMode mode = simpleMode.isSelected() ? 
                SOSGameBase.GameMode.SIMPLE : SOSGameBase.GameMode.GENERAL;
            
            // Get selected size
            int size = sizeCombo.getValue();
            
            // Start new game
            startGame(size, mode);
            
            // Update status message
            statusLabel.setText("Game started - " + 
                (mode == SOSGameBase.GameMode.SIMPLE ? "Simple" : "General") + 
                " mode, Size: " + size);
        });

        // Score display
        blueScoreLabel = new Label("Blue: 0");
        blueScoreLabel.setTextFill(Color.BLUE);
        blueScoreLabel.setFont(new Font(14));
        
        redScoreLabel = new Label("Red: 0");
        redScoreLabel.setTextFill(Color.RED);
        redScoreLabel.setFont(new Font(14));
        
        HBox scoreBox = new HBox(20, blueScoreLabel, redScoreLabel);
        scoreBox.setAlignment(Pos.CENTER);

        // Game board setup
        boardContainer = new Pane();
        boardGrid = new GridPane();
        boardContainer.getChildren().add(boardGrid);
        
        statusLabel = new Label("Select game options and click Start Game");
        statusLabel.setFont(new Font(14));

        // Layout
        HBox optionsPanel = new HBox(10, 
            new Label("Board Size:"), sizeCombo, 
            simpleMode, generalMode, startButton
        );
        optionsPanel.setAlignment(Pos.CENTER);

        VBox root = new VBox(10, optionsPanel, scoreBox, statusLabel, boardContainer);
        root.setPadding(new javafx.geometry.Insets(10));
        root.setAlignment(Pos.TOP_CENTER);

        Scene scene = new Scene(root, 650, 650);
        primaryStage.setScene(scene);
        primaryStage.setTitle("SOS Game");
        primaryStage.show();
    }

    private void startGame(int size, SOSGameBase.GameMode mode) {
        // Clear any existing game elements
        boardGrid.getChildren().clear();
        boardContainer.getChildren().clear();
        
        // Create new game instance of the correct type
        game = SOSGameBase.createGame(mode, size);
        
        // Reset the board display
        boardGrid = new GridPane();
        boardContainer.getChildren().add(boardGrid);
        
        // Initialize the board UI
        updateBoard();
        
        // Reset scores and update status
        if (game instanceof GeneralSOSGame) {
            blueScoreLabel.setText("Blue: 0");
            redScoreLabel.setText("Red: 0");
        }
        updateStatus();
        
        // Set appropriate status message
        statusLabel.setText("Game started - " + 
            (mode == SOSGameBase.GameMode.SIMPLE ? "Simple" : "General") + 
            " mode, Size: " + size);
    }
    
    private void updateBoard() {
        boardGrid.getChildren().clear();
        boardContainer.getChildren().clear();
        boardContainer.getChildren().add(boardGrid);
        
        int size = game.getBoard().getSize();
        boardGrid.setGridLinesVisible(true);

        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                Button cell = createCell(row, col);
                boardGrid.add(cell, col, row);
            }
        }

        if (game instanceof GeneralSOSGame) {
            for (GeneralSOSGame.SOSLine line : ((GeneralSOSGame) game).getAllSosLines()) {
                drawSOSLine(line);
            }
        }
    }

    private Button createCell(int row, int col) {
        Button cell = new Button();
        cell.setMinSize(50, 50);
        cell.setMaxSize(50, 50);
        char symbol = game.getBoard().getBoard()[row][col];
        if (symbol != ' ') {
            cell.setText(String.valueOf(symbol));
            cell.setFont(new Font(18));
            
        }
        
        cell.setOnAction(e -> handleMove(row, col));
        return cell;
    }

    private void drawSOSLine(GeneralSOSGame.SOSLine line) {
        double startX = line.startCol * 50 + 25;
        double startY = line.startRow * 50 + 25;
        double endX = line.endCol * 50 + 25;
        double endY = line.endRow * 50 + 25;
        
        Line sosLine = new Line(startX, startY, endX, endY);
        sosLine.setStroke(line.player.equals("Blue") ? Color.BLUE : Color.RED);
        sosLine.setStrokeWidth(3);
        sosLine.setMouseTransparent(true);
        
        boardContainer.getChildren().add(sosLine);
    }

    private void handleMove(int row, int col) {
        if (game == null || game.isGameOver()) return;

        ChoiceDialog<Character> dialog = new ChoiceDialog<>('S', List.of('S', 'O'));
        dialog.setTitle("Choose Letter");
        dialog.setHeaderText("Player " + game.getCurrentPlayer().getName() + "'s Turn");
        dialog.setContentText("Choose your move:");

        dialog.showAndWait().ifPresent(symbol -> {
            if (game.makeMove(row, col, symbol)) {
                updateBoard();
                updateStatus();
                if (game.isGameOver()) {
                    showGameOverAlert();
                }
            }
        });
    }

    private void updateStatus() {
        if (game == null) {
            statusLabel.setText("Select game options and click Start Game");
            return;
        }
        
        String modeText = (game instanceof SimpleSOSGame) ? "Simple" : "General";
        statusLabel.setText("Current Turn: " + game.getCurrentPlayer().getName() + 
                           " (" + modeText + " mode)");
        
        if (game instanceof GeneralSOSGame) {
            blueScoreLabel.setText("Blue: " + ((GeneralSOSGame) game).getBlueScore());
            redScoreLabel.setText("Red: " + ((GeneralSOSGame) game).getRedScore());
        }
    }
    
    private void showGameOverAlert() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Game Over");
        alert.setHeaderText(null);
        
        String message;
        if (game.getWinner() != null) {
            message = "Player " + game.getWinner() + " wins!\n";
        } else {
            message = "The game is a tie!\n";
        }
        
        if (game instanceof GeneralSOSGame) {
            message += "Final Score - Blue: " + ((GeneralSOSGame) game).getBlueScore() + 
                     " | Red: " + ((GeneralSOSGame) game).getRedScore();
        }
        
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}