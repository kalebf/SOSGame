package com.example.sosgame;

public class SimpleSOSGame extends SOSGameBase {
    public SimpleSOSGame(int boardSize) {
        super(boardSize);
    }

    @Override
    public boolean makeMove(int row, int col, char symbol) {
        if (isGameOver || !board.isCellEmpty(row, col)) {
            return false;
        }

        board.placeSymbol(row, col, symbol);
        
        // Check if this move created any SOS sequences
        boolean sosCreated = checkBasicSOS(row, col, symbol);
        
        if (sosCreated) {
            isGameOver = true;
            winner = currentPlayer.getName();
        } 
        // Only check for draw if board is full AND no SOS was created
        else if (board.isBoardFull()) {
            isGameOver = true;
            winner = null;  // Explicitly set to null for draw
        }

        // Only switch players if game isn't over
        if (!isGameOver) {
            switchPlayer();
        }
        
        return true;
      }
}