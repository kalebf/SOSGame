package com.example.sosgame;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GeneralSOSGameTest {
    @Test
    void testGeneralGameScoring() {
        GeneralSOSGame game = new GeneralSOSGame(3);
        game.makeMove(0, 0, 'S'); // Blue
        game.makeMove(1, 0, 'O'); // Red
        game.makeMove(0, 1, 'O'); // Blue
        game.makeMove(1, 1, 'S'); // Red
        game.makeMove(0, 2, 'S'); // Blue scores
        
        assertEquals(1, game.getBlueScore());
        assertEquals(0, game.getRedScore());
        assertFalse(game.isGameOver());
    }

    @Test
    void testGeneralGameWinner() {
        GeneralSOSGame game = new GeneralSOSGame(3);
        // Blue creates 2 SOS sequences
        game.makeMove(0, 0, 'S');
        game.makeMove(0, 1, 'O');
        game.makeMove(0, 2, 'S');
        
        // Red creates 1 SOS sequence
        game.makeMove(1, 0, 'S');
        game.makeMove(1, 1, 'O');
        game.makeMove(1, 2, 'S');
        
        // Fill remaining cells
        game.makeMove(2, 0, 'S');
        game.makeMove(2, 1, 'O');
        game.makeMove(2, 2, 'S');
        
        assertTrue(game.isGameOver());
        assertEquals("Blue", game.getWinner());
    }
}